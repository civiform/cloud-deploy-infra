
const https = require('https');

exports.handler = async (event) => {
  console.log("SNS Subscription Confirmation Handler Invoked.");
  console.log(JSON.stringify(event, null, 2));

  const records = event.Records || [];
  const confirmUrls = records
    .map(r => r.Sns.SubscribeURL)
    .filter(Boolean);

  for (const url of confirmUrls) {
    console.log(`Confirming subscription at ${url}`);
    await new Promise((resolve, reject) => {
      https.get(url, (res) => {
        if (res.statusCode === 200) {
          console.log("Subscription confirmed successfully.");
          resolve();
        } else {
          console.error(`Failed to confirm: ${res.statusCode}`);
          reject(`Failed with status ${res.statusCode}`);
        }
      }).on('error', reject);
    });
  }

  return { status: 'done' };
};
